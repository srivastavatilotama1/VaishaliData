package com.cg.feedbackApplication.exception;

public class FeedbackException extends Exception {

	
	public FeedbackException(String msg) {
		super(msg);
	}
}
