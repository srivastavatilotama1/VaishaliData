document.write ("This line has been writen in the External JavaScript!!!")
