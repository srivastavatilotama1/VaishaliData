package com.cg.cabs.daotest;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.cabs.bean.CabRequestBean;
import com.cg.cab.dao.CabRequestDAOImpl;
import com.cg.cab.dao.ICabRequestDAO;
import com.cg.cab.exception.CabException;

public class CabTestRequestDaoImpl {
	@Test
	public void addCabRequestDetailsTest() throws CabException
	{
		
		CabRequestBean cabRequestBean = null;
		cabRequestBean = new CabRequestBean();
		
		ICabRequestDAO cabRequestDAO =null;
		cabRequestDAO = new CabRequestDAOImpl();
		cabRequestBean.setCustomerName("puja");
		cabRequestBean.setPhoneNumber("1234567890");
		cabRequestBean.setRequestStatus("ACCEPTED");
		cabRequestBean.setCabNumber("MH TF 8956");
		cabRequestBean.setPickupAddress(" Uttar Pradesh");
		cabRequestBean.setPincode("400708");
		// the sequence number is starting with 1000
		assertTrue(cabRequestDAO.addCabRequestDetails(cabRequestBean)>1000);
		
	}
	
	@Test
	public void isRequesIdPresentTest() throws CabException
	{
		
		CabRequestBean cabRequestBean = null;
		cabRequestBean = new CabRequestBean();
		
		ICabRequestDAO cabRequestDAO =null;
		cabRequestDAO = new CabRequestDAOImpl();
		
		// the sequence number is starting with 1000
		assertTrue(cabRequestDAO.isRequesIdPresent(1002));
		
	}
	
	@Test
	public void getRequestDetailsTest() throws CabException
	{
		
		CabRequestBean cabRequestBean = null;
		cabRequestBean = new CabRequestBean();
		
		ICabRequestDAO cabRequestDAO =null;
		cabRequestDAO = new CabRequestDAOImpl();
		
		// the sequence number is starting with 1000
		try {
			assertNotNull(cabRequestDAO.getRequestDetails(1002));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	
		
	}
}
