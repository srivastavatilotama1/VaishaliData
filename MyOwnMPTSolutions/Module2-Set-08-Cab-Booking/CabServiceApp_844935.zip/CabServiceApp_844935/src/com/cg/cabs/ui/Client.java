package com.cg.cabs.ui;

import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.cab.exception.CabException;
import com.cg.cab.service.CabServiceImpl;
import com.cg.cab.service.ICabService;
import com.cg.cabs.bean.CabRequestBean;
public class Client {

	public static void main(String[] args)  {
			
		String CustName=null;
		String phoneNum=null;
		String addressOfPickup=null;
		String pincode=null;
		int userChoice=0;
		int requestID=0;
		Scanner scanner=new Scanner(System.in);
		CabRequestBean cabRequestBean=null;
		ICabService cabService=null;		
			while(userChoice!=3)
			{
				System.out.println("1.Request for Cab Service");
				System.out.println("2.View Cab request Status");
				System.out.println("3.Exit");
				System.out.println("-----------------------------------------------------------");
				userChoice=scanner.nextInt();
					try
					{
						switch(userChoice)
						{
						case 1:
							//taking user input for customer details
							System.out.println("Enter customer name");
							CustName=scanner.next();
							
							System.out.println("Enter the phone Number");
							phoneNum=scanner.next();
							
							System.out.println("Enter the pick up address");
							addressOfPickup=scanner.next();
							
							System.out.println("Enter the pincode");
							System.out.println("------------------------------------------------------");
							pincode=scanner.next();
							cabRequestBean=new CabRequestBean();
							cabRequestBean.setCustomerName(CustName);
							cabRequestBean.setPhoneNumber(phoneNum);
							cabRequestBean.setPickupAddress(addressOfPickup);
							cabRequestBean.setPincode(pincode);
							
							//validating the customer details
							cabService=new CabServiceImpl();
							cabService.validateCustomerinfo(cabRequestBean);
							
							//checking cabNumber with valid pincode
							cabService.checkCabNumber(cabRequestBean);
							System.out.println("cab Number is"+" "+cabRequestBean.getCabNumber());
							System.out.println("Your request is "+" "+cabRequestBean.getRequestStatus());
							
							//adding the cab request details to database
							 requestID=cabService.addCabRequestDetails(cabRequestBean);
							if(requestID!=0)
							{
								System.out.println("details added sucessfully");
								System.out.println("your request id is"+" "+requestID);
								
							}
							else
								System.out.println("Details can not added right now");
							break; 
						case 2:
							System.out.println("Enter your request Id");
							//to view the cab request details based on request_id
							requestID=scanner.nextInt();
							//validate request id
							try {
								if(cabService.isRequestIdPresent(requestID))
								{
									 
									 cabRequestBean = new CabRequestBean();
									 cabService=new CabServiceImpl();
									
									 cabRequestBean = cabService.getRequestDetails(requestID);
									System.out.println("*****************************************************************");
									System.out.println("Name of the Customer : "+ cabRequestBean.getCustomerName());
									System.out.println("Request Status : "+ cabRequestBean.getRequestStatus());
									System.out.println("Cab Number : "+ cabRequestBean.getCabNumber());
									System.out.println("*****************************************************************");
								}
								else
								{
									System.out.println("Sorry Request id is not present in the database ");
									System.out.println("you can create new id by raising an cab request");
									
								}
							} catch (Exception e) {
								System.out.println(e.getMessage());
							}
							break;
						case 3:
							System.out.println("You are now out of the system");
							break;
						default:
							System.out.println("Enter option 1,2 to continue Else 3 to exit");
						}
				}
					catch(CabException e)
					{
						System.out.println(e.getMessage());
					}
					
			}
			
	}		
}


