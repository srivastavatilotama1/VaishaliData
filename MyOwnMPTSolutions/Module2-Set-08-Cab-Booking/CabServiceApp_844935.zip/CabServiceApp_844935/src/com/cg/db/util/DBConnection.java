package com.cg.db.util;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.cab.exception.CabException;


public class DBConnection {

	
	
	




		private static DBConnection instance;

		private DBConnection() {

		}

		
		//------------------------ 1. Cab Service Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	DBConnection getDBConnection()
			 - Input Parameters	:	None
			 - Return Type		:	DBConnection
			 - Throws			:  	CabException
			 - Author			:	Puja Pandey
			 - Creation Date	:	17/05/2016
			 - Description		:	Getting the  DBConnection Object.
			 ********************************************************************************************************/
		
		public static DBConnection getDBConnection() {
			if (instance == null) {
				instance = new DBConnection(); // Lazy initialization of single tone object
			}
			return instance;
		}

		
		//------------------------ 2. Cab Service Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	Connection getConnection() throws CabException
		 - Input Parameters	:	None
		 - Return Type		:	Connection
		 - Throws			:  	CabException
		 - Author			:	puja Pandey
		 - Creation Date	:	17/05/2016
		 - Description		:	Getting the Connection object.
		 ********************************************************************************************************/
		
		public Connection getConnection() throws CabException {
			FileInputStream fileInputStream = null;
			Properties properties;
			Connection con;
			String url;
			String userName;
			String password;
			try {
				fileInputStream = new FileInputStream("resource/jdbc.properties");
				properties = new Properties();
				properties.load(fileInputStream);
				url = properties.getProperty("jdbc.url");
				userName = properties.getProperty("jdbc.userName");
				password = properties.getProperty("jdbc.password");

				con = DriverManager.getConnection(url, userName, password);

			} catch (FileNotFoundException exp) {
				// TODO Auto-generated catch block
				throw new CabException(exp.getMessage());
			} catch (IOException exp) {
				// TODO Auto-generated catch block
				throw new CabException(exp.getMessage());
			} catch (SQLException exp) {
				// TODO Auto-generated catch block
				throw new CabException(exp.getMessage());
			} finally {
				if (fileInputStream != null) {
					try {
						fileInputStream.close();
					} catch (IOException exp) {
						// TODO Auto-generated catch block
						throw new CabException(exp.getMessage());
					}
				}
			}
			return con;
		}
	}



