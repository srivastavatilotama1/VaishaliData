package com.cg.cab.service;

import com.cg.cab.exception.CabException;
import com.cg.cabs.bean.CabRequestBean;

public interface ICabService {

	void validateCustomerinfo(CabRequestBean cabBean) throws CabException;

	void checkCabNumber(CabRequestBean cabBean) throws CabException;

	int addCabRequestDetails(CabRequestBean cabRequestBean) throws CabException;

	boolean isRequestIdPresent(int requestID) throws Exception;

	CabRequestBean getRequestDetails(int requestID) throws Exception;

}
