package com.cg.cab.exception;

public class CabException extends Exception{

	public CabException(String message) {
		super(message);
	}

}
