package com.cg.cab.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.cab.dao.CabRequestDAOImpl;
import com.cg.cab.dao.ICabRequestDAO;
import com.cg.cab.exception.CabException;
import com.cg.cabs.bean.CabRequestBean;



public class CabServiceImpl implements ICabService {
	ICabRequestDAO cabRequestDAO=null;
	CabRequestBean cabBean=new CabRequestBean();
	
	String cabNumber[][]=	{{"400096","MH VS 2345"},
							{"411026","MH VH 34567"},
							{"411013","MH AN 97886"},
							{"560066","MH AS 875"},
							{"382009","MH KN 9856"},
							{"400708","MH TF 8956"}};
	
	@Override
	public void validateCustomerinfo(CabRequestBean cabBean) throws CabException {
		String custName=cabBean.getCustomerName();
		String phoneNumber=cabBean.getPhoneNumber();
		String address=cabBean.getPickupAddress();
		String pincode=cabBean.getPincode();
		if(!custName.matches("^[a-zA-Z]{3,20}$"))
		{
			throw new CabException("Name should not contain numbers");
		}
		else if(!phoneNumber.matches("^[0-9]{10}$"))
		{
			throw new CabException("phone number should not be greater than 10 digit and should contain digits only");
		}
		else if(!pincode.matches("^[0-9]{6}"))
		{
			throw new CabException("pincode should be of six digit and contain only digits");
		}
		
		
	}

	@Override
	public void checkCabNumber(CabRequestBean cabBean) throws CabException {
		
		int arrLength = cabNumber.length;
		
		for(int idx=0;idx<=arrLength;idx++)
		{
			if(cabNumber[idx][0].equals(cabBean.getPincode()))
			{	
				cabBean.setCabNumber(cabNumber[idx][1]);
				
				cabBean.setRequestStatus("Accepted");
				
				break;
			}
			else
			{
				cabBean.setCabNumber(null);
				cabBean.setRequestStatus("Not Accepted");
			}
			
	} 

	
		
	}

	@Override
	public int addCabRequestDetails(CabRequestBean cabRequestBean)
			throws CabException {
		cabRequestDAO=new CabRequestDAOImpl();
		int status=cabRequestDAO.addCabRequestDetails(cabRequestBean);
		return status;
	}

	@Override
	public boolean isRequestIdPresent(int requestID) throws Exception {
		cabRequestDAO=new CabRequestDAOImpl();
		boolean isRequestIDPresent =false;
		if(cabRequestDAO.isRequesIdPresent(requestID))
		{
			isRequestIDPresent= true;
		}
		else
		{
			isRequestIDPresent= false;
		}
		return isRequestIDPresent;
		
	}

	@Override
	public CabRequestBean getRequestDetails(int requestID) throws Exception {
		CabRequestBean cabReqBean = null;
		cabReqBean = new CabRequestBean();
		//cabRequestDAO=new CabRequestDAOImpl();
		cabReqBean = cabRequestDAO.getRequestDetails(requestID);
		return cabReqBean;
		
		
	}

	

}
