package com.cg.cab.dao;

public class CabQueryMapper {

	public static final String SEQUENCE_QUERY="SELECT SEQUENCE request_id FROM DUAL";
	public static final String INSERT_QUERY="INSERT INTO cab_request VALUES(request_id.NEXTVAL,?,?,SYSDATE,?,?,?,?)";
	public static final String RETRIVE_REQUESTID="SELECT request_id FROM cab_request";
	public static final String SQL_SELECT_GET_DETAILS="SELECT request_id,customer_name,phone_number,date_of_request,request_status,cab_number,address_of_pickup,pincode from cab_request where request_id=? ";
}
