package com.cg.cab.dao;

import com.cg.cab.exception.CabException;
import com.cg.cabs.bean.CabRequestBean;

public interface ICabRequestDAO {

	int addCabRequestDetails(CabRequestBean cabRequestBean) throws CabException;

	boolean isRequesIdPresent(int requestID) throws CabException;

	CabRequestBean getRequestDetails(int requestID) throws Exception;

}
