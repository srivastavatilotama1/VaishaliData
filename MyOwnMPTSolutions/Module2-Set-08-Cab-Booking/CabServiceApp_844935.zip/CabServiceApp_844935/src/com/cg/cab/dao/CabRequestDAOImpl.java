package com.cg.cab.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.cab.exception.CabException;
import com.cg.cabs.bean.CabRequestBean;



import com.cg.db.util.DBConnection;


public class CabRequestDAOImpl implements ICabRequestDAO {
	
	Logger logger=Logger.getRootLogger();
			public CabRequestDAOImpl()
			{
		PropertyConfigurator.configure("resource//log4j.properties");
			}
	@Override
	public int addCabRequestDetails(CabRequestBean cabRequestBean) throws CabException {
		int requestID=0;
		Connection conn=DBConnection.getDBConnection().getConnection();
		PreparedStatement pst=null;
		ResultSet rs=null;
		try
		{
		if(conn!=null)
			{
				pst=conn.prepareStatement(CabQueryMapper.SEQUENCE_QUERY);
				pst=conn.prepareStatement(CabQueryMapper.INSERT_QUERY);
				
				pst.setString(1, cabRequestBean.getCustomerName());
				pst.setString(2, cabRequestBean.getPhoneNumber());
				pst.setString(3, cabRequestBean.getRequestStatus());
				pst.setString(4, cabRequestBean.getCabNumber());
				pst.setString(5, cabRequestBean.getPickupAddress());
				pst.setString(6, cabRequestBean.getPincode());
				
				int result=pst.executeUpdate();
				if(result>0)
				{
					logger.info("added sucessfully");
					pst=conn.prepareStatement(CabQueryMapper.RETRIVE_REQUESTID);
					
					rs=pst.executeQuery();
					
					if(rs.next())
					{
						logger.info("requested id found");
						requestID=rs.getInt("request_id");
					}
					
				}
				else
				{
					requestID=0;
				}	
				
			}
		}
		catch(SQLException e)
		{
			throw new CabException(e.getMessage());
		}
		finally
		{
			try 
			{	
				rs.close();
				pst.close();
				conn.close();
				
			} 
			catch (SQLException e) 
			{
				//logger.error(e.getMessage());
				throw new CabException("Error in closing db connection");

			}
		}
		
		return requestID;
	}

	@Override
	public boolean isRequesIdPresent(int requestID) throws CabException {
		boolean isPresent=false;
		Connection conn=DBConnection.getDBConnection().getConnection();
		PreparedStatement pst=null;
		ResultSet rs=null;
		int result=0;
		String reqId = null;
		
		try
		{
			if(conn!=null)
			{
				pst= conn.prepareStatement(CabQueryMapper.RETRIVE_REQUESTID);
				rs=pst.executeQuery();
				while(rs.next())
				{
					if(rs.getInt("request_id")== requestID)
					{
						isPresent= true; 
						break;
					}
					else
					{
						isPresent= false; 
					}
						
				}
			}
		}
		catch(SQLException e)
		{
			
			throw new CabException("Something went Wrong");
		}
		finally{
			
			try{
				rs.close();
				pst.close();
				conn.close();
				}
			catch(SQLException e)
			{
				
				throw new CabException("Something went Wrong");
			}
		}
		return isPresent;
	}

	@Override
	public CabRequestBean getRequestDetails(int requestID) throws Exception {
		
		Connection conn=DBConnection.getDBConnection().getConnection();
		PreparedStatement pst=null;
		ResultSet rs=null;
		CabRequestBean newCabReqBean = null;
		
		try
		{
			if(conn!=null)
			{
				pst= conn.prepareStatement(CabQueryMapper.SQL_SELECT_GET_DETAILS);
				pst.setInt(1, requestID);
				rs=pst.executeQuery();
				if(rs.next())
				{
					newCabReqBean = new CabRequestBean();
					newCabReqBean.setRequestId(rs.getInt("request_id"));
					newCabReqBean.setCustomerName(rs.getString("customer_name"));
					newCabReqBean.setPhoneNumber(rs.getString("phone_number"));
					newCabReqBean.setRequestDate(String.valueOf(rs.getDate("date_of_request")));
					newCabReqBean.setRequestStatus(rs.getString("request_status"));
					newCabReqBean.setCabNumber(rs.getString("cab_number"));
					newCabReqBean.setPickupAddress(rs.getString("address_of_pickup"));
					newCabReqBean.setPincode(rs.getString("pincode"));
				}
			}
		}
		catch(SQLException e)
		{
			
			throw new CabException("Something went Wrong");
		}
		finally{
			try{
				//rs.close();
				pst.close();
				conn.close();
				}
			catch(SQLException e)
			{
				
				throw new CabException("Something went Wrong");
			}
		}
		return newCabReqBean;
	}

}

