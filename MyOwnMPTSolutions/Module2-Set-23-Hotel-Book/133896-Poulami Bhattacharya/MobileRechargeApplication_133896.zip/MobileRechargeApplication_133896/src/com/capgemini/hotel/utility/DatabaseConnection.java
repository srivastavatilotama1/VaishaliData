package com.capgemini.hotel.utility;





import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DatabaseConnection {
	
	private static Connection con=null;
	
	public static Connection getConnection(){
		
		Properties prop=new Properties();
		if(con==null)
		{
	String url="jdbc:oracle:thin:@10.51.103.201:1521:orcl11g";
	String username="Lab1btrg18";
	String password="lab1boracle";
	String driver=prop.getProperty("driver");
	//Connection con=null;
	//Statement st=null;
	
	try
	{
		FileInputStream fis=new FileInputStream("./resources/jdbc.properties");
		prop.load(fis);
		url=prop.getProperty("url");
		username=prop.getProperty("username");
		password=prop.getProperty("password");
		driver=prop.getProperty("driver");
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection(url,username,password);
		System.out.println("connecting with db....");
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
		
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
		return con;
}
	//return con;
}

