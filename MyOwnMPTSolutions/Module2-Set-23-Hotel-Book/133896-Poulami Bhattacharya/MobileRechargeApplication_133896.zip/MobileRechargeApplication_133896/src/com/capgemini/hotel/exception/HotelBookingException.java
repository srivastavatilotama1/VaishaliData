package com.capgemini.hotel.exception;

public class HotelBookingException extends Exception {

	
		public HotelBookingException(String msg)
		{
			super(msg);
		}

	

}
