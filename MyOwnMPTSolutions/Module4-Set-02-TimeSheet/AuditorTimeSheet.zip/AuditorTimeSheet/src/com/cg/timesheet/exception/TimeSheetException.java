package com.cg.timesheet.exception;

public class TimeSheetException extends Exception{
	public TimeSheetException(String message){
		super(message);
	}
}
