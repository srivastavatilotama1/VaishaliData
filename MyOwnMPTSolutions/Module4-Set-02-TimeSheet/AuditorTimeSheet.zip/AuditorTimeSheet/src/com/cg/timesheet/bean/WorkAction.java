package com.cg.timesheet.bean;

public enum WorkAction {
	DATA_ENTRY,ACCOUNTS_TALLY,LEDGER_POSTINGS,BALANCE_SHEET,RETURNS_FILING;
}
