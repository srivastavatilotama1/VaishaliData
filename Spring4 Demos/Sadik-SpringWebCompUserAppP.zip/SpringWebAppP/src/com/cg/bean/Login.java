package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="cg_users")
public class Login
{
	@Id
	@Column(name="user_name")
	@NotEmpty(message="User name can not be left empty")
	@Pattern(regexp="[A-Za-z ]{2,25}", message="Wrong input, Only characters are allowed")
	private String userName;
	
	@Column(name="password")
	@NotEmpty(message="Password can not be left empty")
	private String password;
	
	public Login(){}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Login [userName=" + userName + ", password=" + password + "]";
	}
}
