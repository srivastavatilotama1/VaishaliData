package com.cg.bean;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="cg_userdetails")
public class Registration 
{
	@Column(name="first_name")
	@NotEmpty(message="First name can not be empty")
	@Pattern(regexp="[A-Za-z ]{1,25}", message="Wrong input, Only characters are allowed")
	private String	firstName;
	
	@Column(name="last_name")
	@NotEmpty(message="Last name can not be empty")
	@Pattern(regexp="[A-Za-z ]{2,25}", message="Wrong input, Only characters are allowed")
	private String	lastName;
	
	@Column(name="user_gender")
	private char	gender;
	
	@Column(name="user_email")
	@NotEmpty(message="Email can not be empty")
	@Email
	private String	email;
	
	@Column(name="user_city")
	private String	city;
	
	@Id
	@Column(name="user_name")
	@NotEmpty(message="User name can not be empty")
	@Pattern(regexp="[A-Za-z0-9]{2,20}", message="No spaces allowed")
	private	String	username;
	
	@NotEmpty(message="Password can not be empty")
	@Pattern(regexp="[A-Za-z0-9]{2,20}", message="No spaces allowed")
	private String	password;

	@NotEmpty(message="Confirm Password can not be empty")
	@Pattern(regexp="[A-Za-z0-9]{2,20}", message="No spaces allowed")
	private String	confirmpassword;
	
	@NotEmpty(message="Please tick skill sets")
	private String[] skillSet;
	
	@Column(name="user_skillset")
	private String	skillSetStr;
	
	public Registration(){}
	
	public Registration(String firstName, String lastName, char gender,
			String email, String[] skillSet, String city, String username,
			String password, String confirmpassword) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.email = email;
		this.skillSet = skillSet;
		this.city = city;
		this.username = username;
		this.password = password;
		this.confirmpassword = confirmpassword;
	}



	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String[] getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String[] skillSet) {
		this.skillSet = skillSet;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	public String getSkillSetStr() {
		return skillSetStr;
	}

	public void setSkillSetStr(String skillSetStr) {
		this.skillSetStr = skillSetStr;
	}

	@Override
	public String toString() {
		return "Registration [firstName=" + firstName + ", lastName="
				+ lastName + ", gender=" + gender + ", email=" + email
				+ ", skillSet=" + Arrays.toString(skillSet) + ", city=" + city
				+ ", username=" + username + ", password=" + password
				+ ", confirmpassword=" + confirmpassword + ", skillSetStr = "+skillSetStr+"]";
	}
}
