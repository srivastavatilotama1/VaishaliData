package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Login;
import com.cg.bean.Registration;

public interface ILoginService 
{
	public Login getUserByUserName(String username);
	public boolean isValid(String username);
	public boolean isUserExisting(String username);
	public Registration registerUser(Registration registration);
	public Login addUser(Login log);
	
	public String getSkillSet(String[] skillSets);
	public ArrayList<Registration> getAllUserDetails();
	public void deleteUser(String username);
	public Registration getUserDetails(String username);
	public void updateDetails(Registration registraion);
}
