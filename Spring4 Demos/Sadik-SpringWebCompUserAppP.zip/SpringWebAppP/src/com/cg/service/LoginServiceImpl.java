package com.cg.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Login;
import com.cg.bean.Registration;
import com.cg.dao.ILoginDao;

@Service("loginService")
@Transactional
public class LoginServiceImpl implements ILoginService
{
	@Autowired
	ILoginDao loginDao;
	
	public ILoginDao getLoginDao() {
		return loginDao;
	}

	public void setLoginDao(ILoginDao loginDao) {
		this.loginDao = loginDao;
	}

	@Override
	public Login getUserByUserName(String username) 
	{
		return loginDao.getUserByUserName(username);
	}

	@Override
	public boolean isValid(String username) 
	{
		return false;
	}

	@Override
	public boolean isUserExisting(String username) 
	{
		return false;
	}

	@Override
	public Registration registerUser(Registration registration)
	{
		return loginDao.registerUser(registration);
	}

	@Override
	public Login addUser(Login log) 
	{
		return loginDao.addUser(log);
	}

	@Override
	public String getSkillSet(String[] skillSets) 
	{
		String skillSet = skillSets[0];

		for(int index=1;index<skillSets.length;index++)
			skillSet = skillSet+","+skillSets[index];
		
		return skillSet;
	}

	@Override
	public ArrayList<Registration> getAllUserDetails() 
	{
		return loginDao.getAllUserDetails();
	}

	@Override
	public void deleteUser(String username)
	{
		loginDao.deleteUser(username);
	}

	@Override
	public Registration getUserDetails(String username) 
	{
		return loginDao.getUserDetails(username);
	}

	@Override
	public void updateDetails(Registration registraion)
	{
		loginDao.updateDetails(registraion);
		
	}
}
