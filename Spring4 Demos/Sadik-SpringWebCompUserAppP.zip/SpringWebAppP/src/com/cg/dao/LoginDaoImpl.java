package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bean.Login;
import com.cg.bean.Registration;

@Repository("loginDao")
public class LoginDaoImpl implements ILoginDao 
{
	@PersistenceContext
	private EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Login getUserByUserName(String username) 
	{
		Login login = entityManager.find(Login.class, username);
		return login;
	}

	@Override
	public boolean isValid(String username) 
	{
		return false;
	}

	@Override
	public boolean isUserExisting(String username) 
	{
		return false;
	}

	@Override
	public Registration registerUser(Registration registration) 
	{
		System.out.println("----------->>>>>>>Inside registration dao");
		System.out.println(registration);
		entityManager.persist(registration);
		entityManager.flush();
		return registration;
	}

	@Override
	public Login addUser(Login log) 
	{
		System.out.println("--------->>>>>>>>Adding login details");
		entityManager.persist(log);
		entityManager.flush();
		return log;
	}

	@Override
	public ArrayList<Registration> getAllUserDetails() 
	{
		System.out.println("------------->>>>>>>>>>>>>>>>Inside get all user Details method");
		String query = "SELECT ud FROM Registration ud";
		TypedQuery<Registration> tq = entityManager.createQuery(query, Registration.class);
		
		ArrayList<Registration> users = (ArrayList<Registration>) tq.getResultList();
		
		return users;
	}

	@Override
	public void deleteUser(String username) 
	{
		entityManager.remove(entityManager.find(Login.class, username));
		entityManager.remove(entityManager.find(Registration.class, username));
		
	}

	@Override
	public Registration getUserDetails(String username) 
	{
		Registration user = entityManager.find(Registration.class, username);
		return user;
	}

	@Override
	public void updateDetails(Registration registraion) 
	{
		entityManager.merge(registraion);
		entityManager.flush();
		
	}

}
