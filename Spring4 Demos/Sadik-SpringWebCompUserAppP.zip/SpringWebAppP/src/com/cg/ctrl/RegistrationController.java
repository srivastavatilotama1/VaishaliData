package com.cg.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Login;
import com.cg.bean.Registration;
import com.cg.service.ILoginService;

@Controller
public class RegistrationController 
{
	@Autowired
	ILoginService loginService;

	ArrayList<String> cityList = null;
	ArrayList<String> skillList = null;
	
	@RequestMapping(value="/displayRegistrationPage")
	public String showRegistrationPage(Model model)
	{
		Registration user = new Registration();
		model.addAttribute("user",user);
		
		cityList = new ArrayList<String>();
		cityList.add("Kolkata");
		cityList.add("Pune");
		cityList.add("Mumbai");
		cityList.add("Bangalore");
		model.addAttribute("cList",cityList);
		
		skillList = new ArrayList<String>();
		
		skillList.add("Java");
		skillList.add(".NET");
		skillList.add("RDBMS");
		skillList.add("Main Frame");
		model.addAttribute("skillSetList",skillList);
		
		return "RegistrationPage";
	}
	
	@RequestMapping(value="/listAllUserDetails")
	public String insertUserDetails(@ModelAttribute(value="user") @Valid Registration registration,
											BindingResult result, Model model)
	{
		if(result.hasErrors())
		{
			cityList = new ArrayList<String>();
			cityList.add("Kolkata");
			cityList.add("Pune");
			cityList.add("Mumbai");
			cityList.add("Bangalore");
			model.addAttribute("cList",cityList);
			
			skillList = new ArrayList<String>();
			
			skillList.add("Java");
			skillList.add(".NET");
			skillList.add("RDBMS");
			skillList.add("Main Frame");
			model.addAttribute("skillSetList",skillList);
			
			return "RegistrationPage";
		}
		
		String[] skillArr = registration.getSkillSet();
		
		String skillSetStr = loginService.getSkillSet(skillArr);	
		
		registration.setSkillSetStr(skillSetStr);
		
		Login lg = new Login();
		lg.setUserName(registration.getUsername());
		lg.setPassword(registration.getPassword());
		
		Registration rd = loginService.registerUser(registration);
		Login logDto = loginService.addUser(lg);
		
		ArrayList<Registration> users = loginService.getAllUserDetails();
		
		model.addAttribute("users",users);
		return "UserDetails";
	}	

	@RequestMapping(value="/getAllUserDetails")
	public String getAllUserInfo(@ModelAttribute(value="user") Registration registration,
											BindingResult result, Model model)
	{
		ArrayList<Registration> users = loginService.getAllUserDetails();
		
		model.addAttribute("users",users);
		return "UserDetails";
	}	
	
	
	@RequestMapping(value="/deleteUser")
	public String deleteUser(@ModelAttribute(value="user") Registration registration,
			BindingResult result, Model model,@RequestParam(value="username") String username)
	{
		loginService.deleteUser(username);
		
		ArrayList<Registration> users = loginService.getAllUserDetails();		
		model.addAttribute("users",users);
		model.addAttribute("msg","Record Successfully deleted");
		return "UserDetails";
	}
	
	@RequestMapping(value="/getEditUser")
	public String getUser(@ModelAttribute(value="user") Registration registration,
			BindingResult result, Model model,@RequestParam(value="username") String username)
	{
		Registration user = loginService.getUserDetails(username);
		model.addAttribute("userDetails",user);
		return "UserDetails";
	}
	
	@RequestMapping(value="/updateDetails")
	public String updateDetails(@ModelAttribute(value="user") Registration registration,
			BindingResult result, Model model)
	{
		loginService.updateDetails(registration);
		model.addAttribute("msg","Details Successfully Update");
		return "UserDetails";
	}
	
	
}
