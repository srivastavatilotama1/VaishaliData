package com.cg.ctrl;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
//class level annotation for url pattern myCtrl/hello.obj
@RequestMapping("myCtrl")
public class HelloController 
{
	//method annotation for url myCtrl/hello.obj
	
	@RequestMapping(value="/hello",method=RequestMethod.GET)
	public ModelAndView sayMsg()
	{
		String date = LocalDate.now().toString();
		
		//Hello is the name of jsp page(i.e., the view shown by the controller)
		//today is name of the model data name(it is similar like the name of the attribute like requestAttribute)
		//date is the parameter that we are passing to today
		return new ModelAndView("Hello","today",date);
	}
}
