package com.cg.ctrl;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.Login;
import com.cg.service.ILoginService;

@Controller
@RequestMapping("loginCtrl")
public class LoginController 
{
	@Autowired
	ILoginService loginService;
	
	public ILoginService getLoginService() {
		return loginService;
	}

	public void setLoginService(ILoginService loginService) {
		this.loginService = loginService;
	}

	@RequestMapping(value="/showLoginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model)
	{
		Login login = new Login();
		model.addAttribute("login",login);
		return "Login";
	}
	
	@RequestMapping(value="/validateLoginDetails")
	//first parameter in the function is to get data from form
	//second parameter in the function is for validation
	//third parameter in the function is for passing data to next views
	public String validateUserDetails(@ModelAttribute(value="login") @Valid Login lgg,
										BindingResult result, Model model)
	{
		if(result.hasErrors())
		{
			
			return "Login";
		}
		
		String username = lgg.getUserName();
		String password = lgg.getPassword();
		
		Login existingUserObj = loginService.getUserByUserName(username);
		
		if(existingUserObj != null)
		{
			if(username.equals(existingUserObj.getUserName()) && password.equals(existingUserObj.getPassword()))
			{
				model.addAttribute("username",username);
				return "Success";
			}
			else
			{
				model.addAttribute("msg","Wrong Password");
				return "Login";
			}
		}
		else
		{
			return "redirect:/displayRegistrationPage.obj";
		}
			
	}
}

