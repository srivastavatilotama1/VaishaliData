/**
 * Created by colinlacy on 2/16/15.
 */
angular.module('factorLink').constant("searchUrl", "http://dev0-factorlinkonline.comfin.ge.com/UnderwriterDev/api/DebtorAPI/SearchDebtors");
angular.module('factorLink').constant("cxUrl", "http://dev0-factorlinkonline.comfin.ge.com/UnderwriterDev/api/DebtorAPI/Connections/");
angular.module('factorLink').constant("currencyUrl", "http://dev0-factorlinkonline.comfin.ge.com/UnderwriterDev/api/systemsettings/availablecurrencies");
