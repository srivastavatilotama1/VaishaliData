/**
 * Created by colinlacy on 2/16/15.
 */
angular.module('factorLink').constant("searchUrl", "http://dev0-factorlinkonline.comfin.ge.com/underwriterQA/api/DebtorAPI/SearchDebtors");
angular.module('factorLink').constant("cxUrl", "http://dev0-factorlinkonline.comfin.ge.com/underwriterQA/api/DebtorAPI/Connections/");
angular.module('factorLink').constant("currencyUrl", "http://dev0-factorlinkonline.comfin.ge.com/underwriterQA/api/systemsettings/availablecurrencies");
