package com.igate.rest.bean;

import java.util.List;

public class UserList {
	
	private List<User> list;

	public void setList(List<User> list) {
		this.list = list;
	}

	public List<User> getList() {
		return list;
	}

}
